#ifndef PARSETREE_H
#define PARSETREE_H
#define typeIntConst 1

#include "parser.h"

int ex(nodeType *p);


#endif
