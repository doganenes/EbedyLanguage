#ifndef PARSEERR_H
#define PARSEERR_H

void yyerror(char *);

#endif
