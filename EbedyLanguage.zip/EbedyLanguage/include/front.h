#ifndef FRONT_H
#define FRONT_H

/* İŞARETLER */
#define HARF 0
#define RAKAM 1
#define TANIMSIZ 99
#define TAMSAYI 10
#define TANIMLAYICI 11
#define ATAMA 20
#define TOPLAMA_OPERATORU 21
#define CIKARMA_OPERATORU 22
#define CARPMA_OPERATORU 23
#define BOLME_OPERATORU 24
#define SOLPARANTEZ 25
#define SAGPARANTEZ 26

int lex();

#endif
